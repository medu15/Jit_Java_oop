 //check which number is maximum
       public class if(x>y){
            System.out.println("x is greater then y");
        }
        else if (x==y){
            System.out.println("x is equal to y");
        }
        else {
            System.out.println("y is greater then x");
        }

        // using conditional operator ?
        (x>y) ? System.out.print("x is greater than y"):System.out.print("y is greater");
        //or 
        system.out.println("max is"+((x>y)?i:j))
