  // to print number 1-10 using while loop
        int counter=0;
        while(counter<=10){
            System.out.println(counter);
            counter++;  
        }
